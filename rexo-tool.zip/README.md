# Rexo Tool - Free Online PDF Tools

A comprehensive single-page web application providing 27 free online PDF tools for managing, editing, and converting PDF files directly in the browser. All processing happens client-side for maximum privacy and security.

## Features

### 27 PDF Tools Included

**Conversion Tools:**
- PDF to Text - Extract text from PDF documents
- PDF to Word - Convert PDF to editable text format
- PDF to PowerPoint - Convert PDF pages to presentation slides
- PDF to JPG - Convert PDF pages to JPG images
- PDF to PNG - Convert PDF pages to PNG images
- JPG to PDF - Convert JPG images to PDF
- PNG to PDF - Convert PNG images to PDF
- Word to PDF - Convert DOCX documents to PDF
- Excel to PDF - Convert spreadsheets to PDF
- HTML to PDF - Convert HTML content to PDF
- Text to PDF - Convert plain text to PDF
- CSV to PDF - Convert CSV data to formatted PDF tables
- JSON to PDF - Convert JSON data to formatted PDF
- XML to PDF - Convert XML data to PDF format

**PDF Management:**
- Merge PDF - Combine multiple PDFs into one document
- Split PDF - Extract specific pages from PDF
- Rotate PDF - Rotate pages 90°, 180°, or 270°
- Delete Pages - Remove unwanted pages from PDF
- Reorder Pages - Rearrange page order in PDF
- Compress PDF - Reduce PDF file size

**PDF Enhancement:**
- Add Watermark - Add text watermarks to PDF
- Add Page Numbers - Insert page numbers
- Sign PDF - Draw and add signature to PDF
- Edit Metadata - Modify PDF title, author, subject, keywords

**Security:**
- Lock PDF - Add password protection
- Unlock PDF - Remove password from PDF

## Technology Stack

- **HTML5** - Semantic markup structure
- **CSS3** - Modern responsive styling with CSS variables
- **JavaScript (ES5)** - Cross-browser compatible scripting
- **External Libraries (CDN):**
  - pdf-lib.js (v1.17.1) - PDF manipulation
  - pdf.js (v2.16.105) - PDF rendering
  - html2pdf.js (v0.10.1) - HTML to PDF conversion
  - mammoth.js (v1.6.0) - DOCX to HTML conversion
  - xlsx.js (v0.18.5) - Excel file handling
  - pptxgenjs (v3.12.0) - PowerPoint generation
  - fabric.js (v5.3.0) - Canvas-based signature drawing
  - jszip (v3.10.1) - ZIP file handling

## Security & Privacy

- **100% Client-Side Processing** - All files are processed in your browser
- **No Server Uploads** - Your files never leave your device
- **No Data Collection** - We don't store or track your files
- **SSL Encryption Ready** - Deploy with HTTPS for secure connections

## Browser Support

- Google Chrome (recommended)
- Mozilla Firefox
- Microsoft Edge
- Safari
- Opera

## File Structure

\`\`\`
rexo-tool/
├── rexo-tool.html    # Main application file (single HTML)
├── README.md         # This file
└── INSTALLATION.md   # Deployment instructions
\`\`\`

## Quick Start

1. Download `rexo-tool.html`
2. Open in any modern web browser
3. Select a tool from the grid
4. Upload your file(s)
5. Process and download the result

## Contact

- **Email:** rexoagency.in@gmail.com
- **Phone:** +91 9116965626
- **Website:** Rexo Agency

## License

Copyright 2025 Rexo Tool. All Rights Reserved.

## Changelog

### Version 1.0.0 (December 2025)
- Initial release with 27 PDF tools
- Responsive design for all devices
- Client-side processing for privacy
- Drag-and-drop file upload
- Touch-enabled signature canvas
