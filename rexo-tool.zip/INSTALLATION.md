# Rexo Tool - Installation & Deployment Guide

This guide explains how to deploy Rexo Tool on various platforms.

---

## Table of Contents

1. [Local Testing](#1-local-testing)
2. [GitHub Pages (Free)](#2-github-pages-free)
3. [Netlify (Free)](#3-netlify-free)
4. [Vercel (Free)](#4-vercel-free)
5. [Shared Hosting](#5-shared-hosting)
6. [VPS/Dedicated Server](#6-vpsdedicated-server)
7. [Google Drive Hosting](#7-google-drive-hosting)
8. [Customization](#8-customization)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Local Testing

### Steps:
1. Download `rexo-tool.html` file
2. Double-click the file to open in your default browser
3. Test all tools to ensure they work correctly

### Note:
Some features may require a local server due to CORS restrictions. Use one of these methods:

**Using Python:**
\`\`\`bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
\`\`\`

**Using Node.js:**
\`\`\`bash
npx serve .
\`\`\`

**Using VS Code:**
Install "Live Server" extension and click "Go Live"

---

## 2. GitHub Pages (Free)

### Steps:

1. **Create GitHub Account**
   - Go to https://github.com
   - Sign up for free account

2. **Create New Repository**
   - Click "New" button
   - Repository name: `rexo-tool` (or your choice)
   - Set to "Public"
   - Click "Create repository"

3. **Upload File**
   - Click "uploading an existing file"
   - Rename `rexo-tool.html` to `index.html`
   - Drag and drop the file
   - Click "Commit changes"

4. **Enable GitHub Pages**
   - Go to Settings > Pages
   - Source: Deploy from a branch
   - Branch: main, / (root)
   - Click Save

5. **Access Your Site**
   - Wait 2-5 minutes
   - Visit: `https://yourusername.github.io/rexo-tool`

### Custom Domain (Optional):
1. Add CNAME file with your domain
2. Configure DNS:
   - Type: CNAME
   - Name: www (or @)
   - Value: yourusername.github.io

---

## 3. Netlify (Free)

### Method 1: Drag & Drop

1. Go to https://netlify.com
2. Sign up / Log in
3. Go to Sites section
4. Drag `rexo-tool.html` (renamed to `index.html`) to the upload area
5. Your site is live instantly!

### Method 2: Git Integration

1. Push code to GitHub/GitLab/Bitbucket
2. Connect repository to Netlify
3. Auto-deploys on every push

### Custom Domain:
1. Go to Domain Settings
2. Add custom domain
3. Configure DNS as instructed

---

## 4. Vercel (Free)

### Steps:

1. Go to https://vercel.com
2. Sign up with GitHub
3. Click "New Project"
4. Import your GitHub repository
5. Deploy

### Or use Vercel CLI:
\`\`\`bash
npm i -g vercel
vercel
\`\`\`

---

## 5. Shared Hosting

### For cPanel Hosting (Hostinger, Bluehost, GoDaddy, etc.):

1. **Login to cPanel**

2. **Open File Manager**
   - Navigate to `public_html` folder

3. **Upload File**
   - Rename `rexo-tool.html` to `index.html`
   - Upload to `public_html`

4. **Access Site**
   - Visit your domain: `https://yourdomain.com`

### For Subdirectory:
1. Create folder in `public_html` (e.g., `tools`)
2. Upload `index.html` to that folder
3. Access: `https://yourdomain.com/tools`

---

## 6. VPS/Dedicated Server

### Using Nginx:

1. **Upload file to server:**
\`\`\`bash
scp rexo-tool.html user@server:/var/www/html/index.html
\`\`\`

2. **Configure Nginx:**
\`\`\`nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/html;
    index index.html;
    
    location / {
        try_files $uri $uri/ =404;
    }
}
\`\`\`

3. **Restart Nginx:**
\`\`\`bash
sudo systemctl restart nginx
\`\`\`

### Using Apache:

1. Upload to `/var/www/html/`
2. Ensure mod_rewrite is enabled
3. Access your domain

---

## 7. Google Drive Hosting

### Note: Limited functionality, not recommended for production

1. Upload `rexo-tool.html` to Google Drive
2. Right-click > Share > Anyone with link
3. Copy link
4. Use a service like DriveToWeb to host

---

## 8. Customization

### Change Branding:

**Logo/Title:**
Find and replace in HTML:
\`\`\`html
<span class="logo-text">Rexo Tool</span>
\`\`\`

**Colors:**
Edit CSS variables in `<style>` section:
\`\`\`css
:root {
    --primary-red: #e5322d;      /* Main brand color */
    --primary-red-dark: #c42a26; /* Hover state */
    --background-light: #f8f8fa; /* Background */
}
\`\`\`

**Contact Information:**
Find footer section and update:
\`\`\`html
<p>rexoagency.in@gmail.com</p>
<p>+91 9116965626</p>
\`\`\`

### Add Google Analytics:

Find this comment in the code and replace:
\`\`\`html
<!-- Google Analytics -->
<!-- 
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'GA_MEASUREMENT_ID');
</script>
-->
\`\`\`

Replace `GA_MEASUREMENT_ID` with your actual tracking ID and uncomment.

### Add Google Search Console:

Add this meta tag in `<head>`:
\`\`\`html
<meta name="google-site-verification" content="YOUR_VERIFICATION_CODE" />
\`\`\`

### Add Advertisements:

Find ad placeholder sections:
\`\`\`html
<div class="ad-placeholder">
    <!-- Replace with your ad code -->
    <p>Advertisement</p>
</div>
\`\`\`

Replace with your AdSense or other ad network code.

---

## 9. Troubleshooting

### Common Issues:

**1. Tools not working / JavaScript errors**
- Ensure you're using HTTPS (some APIs require secure context)
- Check browser console for errors (F12 > Console)
- Try a different browser

**2. File upload not working**
- Check file size limits
- Ensure correct file type is selected
- Clear browser cache

**3. Fonts not loading**
- System fonts are used, should work everywhere
- Check for CSS loading errors

**4. Mobile layout issues**
- Clear browser cache
- Test in incognito mode
- Check viewport meta tag is present

**5. PDF processing fails**
- Ensure PDF is not corrupted
- Try with a smaller file first
- Check if PDF is password protected

### Browser Console Errors:

Open browser console (F12) and check for:
- CORS errors - Use HTTPS
- Script loading errors - Check CDN links
- Memory errors - File may be too large

### Contact Support:

If issues persist:
- Email: rexoagency.in@gmail.com
- Phone: +91 9116965626

---

## Performance Tips

1. **Enable Gzip Compression** on your server
2. **Use CDN** for faster loading worldwide
3. **Enable Browser Caching** in server config
4. **Use HTTPS** for security and SEO

---

## SEO Checklist

After deployment:

- [ ] Submit sitemap to Google Search Console
- [ ] Add Google Analytics tracking
- [ ] Verify meta tags are correct
- [ ] Test page speed on Google PageSpeed Insights
- [ ] Check mobile-friendliness on Google Mobile Test
- [ ] Submit to Bing Webmaster Tools
- [ ] Add structured data if needed

---

## Security Checklist

- [ ] HTTPS enabled
- [ ] Security headers configured
- [ ] No sensitive data in code
- [ ] Regular backups scheduled
- [ ] CDN links use HTTPS

---

Created by Rexo Agency
Copyright 2025 - All Rights Reserved
